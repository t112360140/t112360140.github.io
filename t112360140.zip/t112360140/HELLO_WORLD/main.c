

/**
 * main.c
 */
int main(void)
{
    printf("ANSI C printf : Hello World\n");
	return 0;
}
